﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T5_ADAA_11806_parte2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Bienvenido");
            Console.Write("Ingresa el monto total de tu compra: Q");
            double total = Convert.ToDouble(Console.ReadLine());
            string codigo;
            string pregunta;

            if (total > 0)
            {
                if (total < 400)
                {
                    Console.WriteLine("No hay descuento, ¿pero tiene codigo de descuento?");
                    pregunta = Console.ReadLine();
                    if (pregunta == "si")
                    {
                        Console.WriteLine("Ingresa el codigo");
                        codigo = Console.ReadLine();
                        if (codigo == "serena")
                        {
                            total = total - (total * 0.5);
                            Console.WriteLine("Su total es de: Q" + total);
                        }
                        else
                        {
                            Console.WriteLine("Codigo incorrecto, su total es de: Q" + total);
                        }
                    }
                    else
                    {
                        Console.WriteLine("Su total es de: Q" + total);
                    }
                }
                else
                {
                    if (total < 1000)
                    {
                        total = total - (total * 0.07);
                        Console.WriteLine("Se descontara 7% del total, ¿tiene codigo de descuento?");
                        pregunta = Console.ReadLine();
                        if (pregunta == "si")
                        {
                            Console.WriteLine("Ingresa el codigo");
                            codigo = Console.ReadLine();
                            if (codigo == "serena")
                            {
                                total = total - (total * 0.05);
                                Console.WriteLine("Su total es de: Q" + total);
                            }
                            else
                            {
                                Console.WriteLine("Codigo incorrecto, su total es de: Q" + total);
                            }
                        }
                        else
                        {
                            Console.WriteLine("Su total es de: Q" + total);
                        }
                    }
                    else
                    {
                        if (total < 5000)
                        {
                            total = total - (total * 0.10);
                            Console.WriteLine("Se descontara 10% del total, ¿tiene codigo de descuento?");
                            pregunta = Console.ReadLine();
                            if (pregunta == "si")
                            {
                                Console.WriteLine("Ingresa el codigo");
                                codigo = Console.ReadLine();
                                if (codigo == "serena")
                                {
                                    total = total - (total * 0.05);
                                    Console.WriteLine("Su total es de: Q" + total);
                                }
                                else
                                {
                                    Console.WriteLine("Codigo incorrecto, su total es de: Q" + total);
                                }
                            }
                            else
                            {
                                Console.WriteLine("Su total es de: Q" + total);
                            }
                        }
                        else
                        {
                            if (total <15000)
                            {
                                total = total - (total * 0.15);
                                Console.WriteLine("Se descontara 15% del total, ¿tiene codigo de descuento?");
                                pregunta = Console.ReadLine();
                                if (pregunta == "si")
                                {
                                    Console.WriteLine("Ingresa el codigo");
                                    codigo = Console.ReadLine();
                                    if (codigo == "serena")
                                    {
                                        total = total - (total * 0.05);
                                        Console.WriteLine("Su total es de: Q" + total);
                                    }
                                    else
                                    {
                                        Console.WriteLine("Codigo incorrecto, su total es de: Q" + total);
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Su total es de: Q" + total);
                                }
                            }
                            else
                            {
                                total = total - (total * 0.25);
                                Console.WriteLine("Se descontara 25% del total, ¿tiene codigo de descuento?");
                                pregunta = Console.ReadLine();
                                if (pregunta == "si")
                                {
                                    Console.WriteLine("Ingresa el codigo");
                                    codigo = Console.ReadLine();
                                    if (codigo == "serena")
                                    {
                                        total = total - (total * 0.05);
                                        Console.WriteLine("Su total es de: Q" + total);
                                    }
                                    else
                                    {
                                        Console.WriteLine("Codigo incorrecto, su total es de: Q" + total);
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Su total es de: Q" + total);
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("Monto invalido");
            }
            Console.ReadKey();
        }
    }
}
