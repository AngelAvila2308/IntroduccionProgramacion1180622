﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L5_Angel_Avila_1180622
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Escoja que desea hacer: ");
            Console.WriteLine("1: Determinar si es positivo o negativo");
            Console.WriteLine("2: Determinar el dia de la semana");
            int elec = Convert.ToInt32(Console.ReadLine());
            if (elec == 1)
            {
                Console.WriteLine("ingresa un numero para saber si es positivo o negativo: ");
                string n;
                n = Console.ReadLine();
                int number = Convert.ToInt32(n);

                if (number > 0)
                {
                    Console.WriteLine("El numero " + number + " es positivo");
                }
                else if (number < 0)
                {
                    Console.WriteLine("El numero " + number + " es negativo");

                }
                else
                {
                    Console.WriteLine("No vale el cero");

                }
                Console.ReadKey();
            }
            else if (elec == 2)
            {
                Console.WriteLine("ingresa un numero para saber a que dia de la semana pertenece: ");
                string numero;
                numero = Console.ReadLine();
                int oremun = Convert.ToInt32(numero);

                if (oremun == 1)
                {
                    Console.WriteLine("El numero " + oremun + " representa lunes");
                }
                else if (oremun == 2)
                {
                    Console.WriteLine("El numero " + oremun + " representa martes");
                }
                else if (oremun == 3)
                {
                    Console.WriteLine("El numero " + oremun + " representa miercoles");
                }
                else if (oremun == 4)
                {
                    Console.WriteLine("El numero " + oremun + " representa jueves");
                }
                else if (oremun == 5)
                {
                    Console.WriteLine("El numero " + oremun + " representa viernes");
                }
                else if (oremun == 6)
                {
                    Console.WriteLine("El numero " + oremun + " representa sabado");
                }
                else if (oremun == 7)
                {
                    Console.WriteLine("El numero " + oremun + " representa domingo");
                }
            }
            else
            {
                Console.WriteLine("Proximamente");
            }
            
        }
    }
}
