﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T5_AngelAvila_1180622
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingresa 3 cifras en Quetzales");
            Console.WriteLine("Valor 1: ");
            double q1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Valor 2: ");
            double q2 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Valor 3: ");
            double q3 = Convert.ToDouble(Console.ReadLine());
            q1 = q1 * 0.13;
            q2 = q2 * 0.13;
            q3 = q3 * 0.13;

            if (q1 > q2)
            {
                if (q1 > q3)
                {
                    Console.WriteLine("El primer valor es mayor: " + q1);
                }
                else if (q1 == q2)
                {
                    if (q1 == q3)
                    {
                        Console.WriteLine("los tres valores son los mismos, primer valor: " + q1 + " segundo valor: " + q2 + " tercer valor: " + q3);
                    }
                    else
                    {
                        Console.WriteLine("El primer y segundo valor son los mayores, primer valor: " + q1 + " Segundo valor: " + q2);
                    }
                }
            }
            else if (q2 > q3)
            {
                Console.WriteLine("El segundo valor es el mayor, segundo valor: " + q2);
            }
            else if (q2 == q3)
            {
                if (q1 == q3)
                {
                    Console.WriteLine("los tres valores son los mismos, primer valor: " + q1 + " segundo valor: " + q2 + " tercer valor: " + q3);
                }
                else
                {
                    Console.WriteLine("El segundo y tercer valor son los mayores, segundo valor: " + q2 + " Tercer valor: " + q3);
                }
            }
            else
            {
                Console.WriteLine("El tercer valor es el mayor, tercer valor: " + q3);
            }
            Console.ReadKey();
        }
    }
}
