﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L6_ADAA_1180622
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 1");
            Console.WriteLine("Ingresar un numero para saber el numero del mes: ");
            int mes = Convert.ToInt32(Console.ReadLine());

            if(mes < 0 || mes > 12)
            {
                Console.WriteLine("Error: El número a ingresar debe estar contenido entre 1 y 12.");
            }
            else
            {
                switch (mes)
                {
                    case 1: Console.WriteLine("Mes: Enero");
                        break;
                    case 2:
                        Console.WriteLine("Mes: Febrero");
                        break;
                    case 3:
                        Console.WriteLine("Mes: Marzo");
                        break;
                    case 4:
                        Console.WriteLine("Mes: Abril");
                        break;
                    case 5:
                        Console.WriteLine("Mes: Mayo");
                        break;
                    case 6:
                        Console.WriteLine("Mes: Junio");
                        break;
                    case 7:
                        Console.WriteLine("Mes: Julio");
                        break;
                    case 8:
                        Console.WriteLine("Mes: Agosto");
                        break;
                    case 9:
                        Console.WriteLine("Mes: Septiembre");
                        break;
                    case 10:
                        Console.WriteLine("Mes: Octubre");
                        break;
                    case 11:
                        Console.WriteLine("Mes: Noviembre");
                        break;
                    case 12:
                        Console.WriteLine("Mes: Diciembre");
                        break;
                }

            }
            Console.ReadKey();
        }
    }
}
