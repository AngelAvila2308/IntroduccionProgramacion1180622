﻿namespace Lab10_ADAA_1180622
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.inputCargo = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.botonCargarDatos = new System.Windows.Forms.Button();
            this.inputDescripcion = new System.Windows.Forms.RichTextBox();
            this.inputPrecio = new System.Windows.Forms.NumericUpDown();
            this.inputModelo = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.inputMarca = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.botonActualizar = new System.Windows.Forms.Button();
            this.outputPrecioFinal = new System.Windows.Forms.Label();
            this.botonCalcularPrecio = new System.Windows.Forms.Button();
            this.inputIVA = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.OutputDescripcion = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.OutputPrecio = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.OutputModelo = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.outputMarca = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.inputCargo.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inputPrecio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputModelo)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inputIVA)).BeginInit();
            this.SuspendLayout();
            // 
            // inputCargo
            // 
            this.inputCargo.Controls.Add(this.tabPage1);
            this.inputCargo.Controls.Add(this.tabPage2);
            this.inputCargo.Location = new System.Drawing.Point(89, 28);
            this.inputCargo.Name = "inputCargo";
            this.inputCargo.SelectedIndex = 0;
            this.inputCargo.Size = new System.Drawing.Size(639, 410);
            this.inputCargo.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.tabPage1.Controls.Add(this.botonCargarDatos);
            this.tabPage1.Controls.Add(this.inputDescripcion);
            this.tabPage1.Controls.Add(this.inputPrecio);
            this.tabPage1.Controls.Add(this.inputModelo);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.inputMarca);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(631, 384);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Ingreso de Datos";
            // 
            // botonCargarDatos
            // 
            this.botonCargarDatos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.botonCargarDatos.Location = new System.Drawing.Point(197, 278);
            this.botonCargarDatos.Name = "botonCargarDatos";
            this.botonCargarDatos.Size = new System.Drawing.Size(262, 69);
            this.botonCargarDatos.TabIndex = 11;
            this.botonCargarDatos.Text = "Cargo Datos";
            this.botonCargarDatos.UseVisualStyleBackColor = false;
            this.botonCargarDatos.Click += new System.EventHandler(this.botonCargarDatos_Click);
            // 
            // inputDescripcion
            // 
            this.inputDescripcion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.inputDescripcion.Location = new System.Drawing.Point(127, 187);
            this.inputDescripcion.Name = "inputDescripcion";
            this.inputDescripcion.Size = new System.Drawing.Size(421, 85);
            this.inputDescripcion.TabIndex = 10;
            this.inputDescripcion.Text = "";
            // 
            // inputPrecio
            // 
            this.inputPrecio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.inputPrecio.DecimalPlaces = 2;
            this.inputPrecio.Increment = new decimal(new int[] {
            50,
            0,
            0,
            131072});
            this.inputPrecio.Location = new System.Drawing.Point(128, 148);
            this.inputPrecio.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.inputPrecio.Name = "inputPrecio";
            this.inputPrecio.Size = new System.Drawing.Size(421, 20);
            this.inputPrecio.TabIndex = 9;
            this.inputPrecio.ThousandsSeparator = true;
            // 
            // inputModelo
            // 
            this.inputModelo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.inputModelo.Location = new System.Drawing.Point(128, 111);
            this.inputModelo.Maximum = new decimal(new int[] {
            2023,
            0,
            0,
            0});
            this.inputModelo.Minimum = new decimal(new int[] {
            2007,
            0,
            0,
            0});
            this.inputModelo.Name = "inputModelo";
            this.inputModelo.Size = new System.Drawing.Size(421, 20);
            this.inputModelo.TabIndex = 8;
            this.inputModelo.ThousandsSeparator = true;
            this.inputModelo.Value = new decimal(new int[] {
            2007,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(53, 189);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Descripcion";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(53, 150);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Precio";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(53, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Modelo";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(53, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Marca";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(40, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "Carros";
            // 
            // inputMarca
            // 
            this.inputMarca.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.inputMarca.Location = new System.Drawing.Point(128, 60);
            this.inputMarca.Name = "inputMarca";
            this.inputMarca.Size = new System.Drawing.Size(421, 20);
            this.inputMarca.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Cyan;
            this.tabPage2.Controls.Add(this.botonActualizar);
            this.tabPage2.Controls.Add(this.outputPrecioFinal);
            this.tabPage2.Controls.Add(this.botonCalcularPrecio);
            this.tabPage2.Controls.Add(this.inputIVA);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.OutputDescripcion);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.OutputPrecio);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.OutputModelo);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.outputMarca);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(631, 384);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Ver Datos";
            // 
            // botonActualizar
            // 
            this.botonActualizar.BackColor = System.Drawing.Color.Purple;
            this.botonActualizar.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonActualizar.Location = new System.Drawing.Point(96, 17);
            this.botonActualizar.Name = "botonActualizar";
            this.botonActualizar.Size = new System.Drawing.Size(416, 72);
            this.botonActualizar.TabIndex = 14;
            this.botonActualizar.Text = "Refrescar";
            this.botonActualizar.UseVisualStyleBackColor = false;
            this.botonActualizar.Click += new System.EventHandler(this.botonActualizar_Click);
            // 
            // outputPrecioFinal
            // 
            this.outputPrecioFinal.AutoSize = true;
            this.outputPrecioFinal.Location = new System.Drawing.Point(141, 333);
            this.outputPrecioFinal.Name = "outputPrecioFinal";
            this.outputPrecioFinal.Size = new System.Drawing.Size(62, 13);
            this.outputPrecioFinal.TabIndex = 13;
            this.outputPrecioFinal.Text = "Precio Final";
            // 
            // botonCalcularPrecio
            // 
            this.botonCalcularPrecio.BackColor = System.Drawing.Color.Purple;
            this.botonCalcularPrecio.Location = new System.Drawing.Point(143, 273);
            this.botonCalcularPrecio.Name = "botonCalcularPrecio";
            this.botonCalcularPrecio.Size = new System.Drawing.Size(119, 38);
            this.botonCalcularPrecio.TabIndex = 12;
            this.botonCalcularPrecio.Text = "Calcular Precio Final";
            this.botonCalcularPrecio.UseVisualStyleBackColor = false;
            this.botonCalcularPrecio.Click += new System.EventHandler(this.botonCalcularPrecio_Click);
            // 
            // inputIVA
            // 
            this.inputIVA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.inputIVA.DecimalPlaces = 2;
            this.inputIVA.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.inputIVA.Location = new System.Drawing.Point(142, 247);
            this.inputIVA.Name = "inputIVA";
            this.inputIVA.Size = new System.Drawing.Size(120, 20);
            this.inputIVA.TabIndex = 11;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(58, 333);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(62, 13);
            this.label15.TabIndex = 10;
            this.label15.Text = "Precio Final";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(58, 249);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(24, 13);
            this.label14.TabIndex = 9;
            this.label14.Text = "IVA";
            // 
            // OutputDescripcion
            // 
            this.OutputDescripcion.AutoSize = true;
            this.OutputDescripcion.Location = new System.Drawing.Point(139, 213);
            this.OutputDescripcion.Name = "OutputDescripcion";
            this.OutputDescripcion.Size = new System.Drawing.Size(63, 13);
            this.OutputDescripcion.TabIndex = 8;
            this.OutputDescripcion.Text = "Descripcion";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(57, 213);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 13);
            this.label12.TabIndex = 7;
            this.label12.Text = "Descripcion";
            // 
            // OutputPrecio
            // 
            this.OutputPrecio.AutoSize = true;
            this.OutputPrecio.Location = new System.Drawing.Point(139, 180);
            this.OutputPrecio.Name = "OutputPrecio";
            this.OutputPrecio.Size = new System.Drawing.Size(37, 13);
            this.OutputPrecio.TabIndex = 6;
            this.OutputPrecio.Text = "Precio";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(57, 180);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 13);
            this.label10.TabIndex = 5;
            this.label10.Text = "Precio";
            // 
            // OutputModelo
            // 
            this.OutputModelo.AutoSize = true;
            this.OutputModelo.Location = new System.Drawing.Point(140, 151);
            this.OutputModelo.Name = "OutputModelo";
            this.OutputModelo.Size = new System.Drawing.Size(42, 13);
            this.OutputModelo.TabIndex = 4;
            this.OutputModelo.Text = "Modelo";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(57, 151);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "Modelo";
            // 
            // outputMarca
            // 
            this.outputMarca.AutoSize = true;
            this.outputMarca.Location = new System.Drawing.Point(139, 121);
            this.outputMarca.Name = "outputMarca";
            this.outputMarca.Size = new System.Drawing.Size(37, 13);
            this.outputMarca.TabIndex = 2;
            this.outputMarca.Text = "Marca";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(57, 121);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Marca";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.inputCargo);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.inputCargo.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inputPrecio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputModelo)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inputIVA)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl inputCargo;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox inputMarca;
        private System.Windows.Forms.RichTextBox inputDescripcion;
        private System.Windows.Forms.NumericUpDown inputPrecio;
        private System.Windows.Forms.NumericUpDown inputModelo;
        private System.Windows.Forms.Button botonCargarDatos;
        private System.Windows.Forms.Button botonCalcularPrecio;
        private System.Windows.Forms.NumericUpDown inputIVA;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label OutputDescripcion;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label OutputPrecio;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label OutputModelo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label outputMarca;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label outputPrecioFinal;
        private System.Windows.Forms.Button botonActualizar;
    }
}

