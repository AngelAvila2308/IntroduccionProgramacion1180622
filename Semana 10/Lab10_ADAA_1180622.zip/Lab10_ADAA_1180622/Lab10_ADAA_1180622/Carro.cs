﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_ADAA_1180622
{
    internal class Carro
    {
        private string Marca = "";
        private int Modelo = 0;
        private double Precio = 0;
        private string Desc = "";
        private double Iva = 0;
        private double PrecioConIva = 0;
        private int calculo = 0;

        public void SetMarca (string marca)
        {
            if (marca != "")
            {
                this.Marca = marca;
            }


        }
        public void SetModelo (int modelo)
        {
            this.Modelo = modelo;

        }
        public void SetPrecio (double precio)
        {
            this.Precio = precio;

        }
        public void SetDescripcion(string desc)
        {
            this.Desc = Desc + " " + desc;
        }

        public string LeerMarca()
        {
            return Marca;
        }

        public int LeerModelo()
        {
            return Modelo;
        }

        public double LeerPrecio()
        {
            return this.Precio;
        }
        public string LeerDescripcion()
        {
            return Desc;
        }

        public double CalcularIva(double ivaActual)
        {
            PrecioConIva = Precio + (Precio*(ivaActual/100));
            return PrecioConIva;

        }

        public void SetPrecioFinal(double precioConIva)
        {
            this.PrecioConIva = precioConIva;
        }
        public double LeerPrecioFinal()
        {
            return this.PrecioConIva;
        }

        public void Calcularletras(int calcular)
        {
            this.calculo = calcular;
        }
        public int LeerLength()
        {
            return this.calculo;
        }


    } 
}
