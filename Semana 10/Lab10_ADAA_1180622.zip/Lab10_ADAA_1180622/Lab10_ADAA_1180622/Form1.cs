﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab10_ADAA_1180622
{
    public partial class Form1 : Form
    {
        Carro nuevoCarro = new Carro();

        public Form1()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void botonCargarDatos_Click(object sender, EventArgs e)
        {

            string marca = inputMarca.Text;
            int modelo = (int) inputModelo.Value;
            double precio = (double)inputPrecio.Value;
            string descripcion = inputDescripcion.Text;
            int calculo = 0;

            calculo = marca.Length;
            if (marca == "")
            {
                MessageBox.Show("No puede estar vacia la marca", "No dejar en blanco");  
            }
            else 
            {
                if (nuevoCarro.LeerLength() == 0)
                {
                    nuevoCarro.SetMarca(marca);
                    nuevoCarro.SetDescripcion(descripcion);
                    nuevoCarro.Calcularletras(calculo);
                    nuevoCarro.SetModelo(modelo);
                    inputModelo.Value = 2007;
                }
                else if (calculo == nuevoCarro.LeerLength())
                {
                    nuevoCarro.SetMarca(marca);
                    nuevoCarro.SetDescripcion(descripcion);
                    nuevoCarro.Calcularletras(calculo);
                    nuevoCarro.SetModelo(modelo);
                    inputModelo.Value = 2007;
                }
                else
                {

                    MessageBox.Show("El valor debe tener una longitud igual al actual valor de Marca", "Advertencia");
                }
            }
            if (precio == 0)
            {
                MessageBox.Show("No puede estar vacio su precio", "Debe llenarlo");
            }
            else
            {

                if (nuevoCarro.LeerPrecio() == 0)
                {
                    nuevoCarro.SetPrecio(precio);
                }
                else if (precio <= nuevoCarro.LeerPrecio())
                {
                    nuevoCarro.SetPrecio(precio);
                }
                else
                {
                    MessageBox.Show("El precio no puede superar al precio anterior", "Precio no valido");
                }
            }
        }

        private void botonActualizar_Click(object sender, EventArgs e)
        {
            outputMarca.Text = nuevoCarro.LeerMarca();
            OutputDescripcion.Text = nuevoCarro.LeerDescripcion();
            OutputPrecio.Text = nuevoCarro.LeerPrecio().ToString();
            OutputModelo.Text = nuevoCarro.LeerModelo().ToString();
        }

        private void botonCalcularPrecio_Click(object sender, EventArgs e)
        {
            double ivaIngresado = (double)inputIVA.Value;
            nuevoCarro.CalcularIva(ivaIngresado);

            outputPrecioFinal.Text = nuevoCarro.LeerPrecioFinal().ToString();
        }
    }
}
