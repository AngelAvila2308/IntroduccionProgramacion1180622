﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab8_AngelAvila_1180622
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese su nombre: ");
            string nombre;
            nombre = Console.ReadLine();
            Console.WriteLine("Bienvenido: " + nombre);

            Console.WriteLine("ingrese el numero de Fibonacci que quiere saber: ");
            int numero;
            numero = Convert.ToInt16(Console.ReadLine());

            if (numero <= 0)
            {
                Console.WriteLine("Ese numero no existe en Fibonacci");
            }
            else if(numero == 1)
            {
                Console.WriteLine(0);
            }
            else if(numero == 2)
            {
                Console.WriteLine(1);
            }
            else
            {
                int resultado = 0;
                int numeroanterior1 = 0;
                int numeroanterior2 = 1;

                for (int i = 3; i <= numero; i++)
                {
                    resultado = numeroanterior1 + numeroanterior2;
                    numeroanterior1 = numeroanterior2;
                    numeroanterior2 = resultado;
                }
                Console.WriteLine(resultado);
            }
            Console.ReadKey();
        }
    }
}
