﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L6_ADAA_1180622_parte2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 2");
            Console.WriteLine("Ingrese numero 1: ");
            int A = int.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese numero 2: ");
            int B = int.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese numero 3: ");
            int C = int.Parse(Console.ReadLine());

            if (A > B)
            {
                if (A > C)
                {
                    Console.WriteLine("El primer numero es el mayor: " + A);
                }
                else
                {
                    if (A == C)
                    {
                        Console.WriteLine("El primer  y tercer numero son los mayores: 1)" + A + " 3)" + C);
                    }
                    else
                    {
                        Console.WriteLine("El tercer numero es el mayor: " + C);
                    }
                }
            }
            else
            {
                if (A == B)
                {
                    if (A > C)
                    {
                        Console.WriteLine("El primer  y segundo numero son los mayores: 1)" + A + " 2)" + B);
                    }
                    else
                    {
                        if (A == C)
                        {
                            Console.WriteLine("Los tres numeros son iguales");
                        }
                        else
                        {
                            Console.WriteLine("El tercer numero es el mayor: " + C);
                        }
                    }
                }
                else
                {
                    if (B > C)
                    {
                        Console.WriteLine("El segundo numero es el mayor: " + B);
                    }
                    else
                    {
                        if (B == C)
                        {
                            Console.WriteLine("El segundo y tercer numero son los mayores: 2)" + B + " 3)" + C);
                        }

                        else
                        {
                            Console.WriteLine("El tercer numero es el mayor: " + C);
                        }
                    }
                }
            }
            Console.ReadKey();
        }
    }
}
